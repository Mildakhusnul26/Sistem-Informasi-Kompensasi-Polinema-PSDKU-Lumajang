@extends('layouts.app')


@section('title','Baru')

@section('content')
    <section class="section">
          <div class="section-header">
            <h1>Baru Page</h1>
          </div>

          <div class="section-body">
          Content Here
          </div>
        </section>
@endsection

@section('sidebar')
@endsection