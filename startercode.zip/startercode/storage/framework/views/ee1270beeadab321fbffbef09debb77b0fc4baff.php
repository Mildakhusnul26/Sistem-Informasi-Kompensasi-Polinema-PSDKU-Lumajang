

<?php $__env->startSection('title','User List'); ?>

<?php $__env->startSection('content'); ?>

<section class="section">
          <div class="section-header">
            <h1>Rekap Kompen</h1>
          </div>

          <div class="section-body">
            <h2 class="section-title">Users</h2>
            <p class="section-lead">
              Manage Your Users Here
            </p>
          </div>
          <div class="row mt-4">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4>All Posts</h4>
                </div>
                <div class="card-body">
                  
                  <div class="float-right">
                    <form method="GET">
                      <div class="input-group">
                        <input name="search" type="text" class="form-control" placeholder="Search">
                        <div class="input-group-append">
                          <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>

                  <div class="clearfix mb-3"></div>

                  <div class="table-responsive">
                    <table class="table table-striped">
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Semester</th>
                        <th>Kompen</th>
                      </tr>
                      <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td>
                            <?php echo e($index + $users->firstItem()); ?>

                        </td>
                        <td><?php echo e($user->name); ?>

                          <div class="table-links">
                            <a href="#">View</a>
                            <div class="bullet"></div>
                            <a href="#">Edit</a>
                            <div class="bullet"></div>
                            <a href="#" class="text-danger">Trash</a>
                          </div>
                        </td>
                        <td>
                          <?php echo e($user->email); ?>

                        </td>
                        <td>
                          <?php echo e($user->phone); ?>

                        </td>
                        <td>
                            <?php if($user->email_verified_at != null): ?>
                                <div class="badge badge-success">Active</div>
                                
                            <?php else: ?>
                                <div class="badge badge-warning">Pending</div>
                            <?php endif; ?>
                            
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>
                            No Data Found
                        </td>
                      </tr>
                      <?php endif; ?>
                      
                    </table>
                  </div>
                  <div class="float-right">
                    <nav>
                      <ul class="pagination">
                       <?php echo e($users->withQueryString()->links()); ?>

                      </ul>
                    </nav>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

<li class="menu-header">Starter</li>
              <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Layout</span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="layout-default.html">Default Layout</a></li>
                  <li><a class="nav-link" href="layout-transparent.html">Transparent Sidebar</a></li>
                  <li><a class="nav-link" href="layout-top-navigation.html">Top Navigation</a></li>
                </ul>
              </li>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\startercode\resources\views/user/index.blade.php ENDPATH**/ ?>