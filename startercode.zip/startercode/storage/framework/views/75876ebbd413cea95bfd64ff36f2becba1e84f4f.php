

<?php $__env->startSection('title','Homepage'); ?>

<?php $__env->startSection('content'); ?>

<section class="section">
          <div class="section-header">
            <h1>Home Page</h1>
          </div>

          <div class="section-body">
          </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

<li class="menu-header">Starter</li>
              <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Layout</span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="layout-default.html">Default Layout</a></li>
                  <li><a class="nav-link" href="layout-transparent.html">Transparent Sidebar</a></li>
                  <li><a class="nav-link" href="layout-top-navigation.html">Top Navigation</a></li>
                </ul>
              </li>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\startercode\resources\views/dashboard/home.blade.php ENDPATH**/ ?>