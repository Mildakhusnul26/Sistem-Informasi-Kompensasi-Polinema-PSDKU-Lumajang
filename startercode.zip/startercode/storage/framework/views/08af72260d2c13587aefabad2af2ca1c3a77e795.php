


<?php $__env->startSection('title','Baru'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
          <div class="section-header">
            <h1>Baru Page</h1>
          </div>

          <div class="section-body">
          Content Here
          </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\startercode\resources\views/dashboard/baru.blade.php ENDPATH**/ ?>